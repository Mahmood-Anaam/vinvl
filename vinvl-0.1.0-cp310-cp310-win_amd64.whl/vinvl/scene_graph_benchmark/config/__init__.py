# Copyright (c) 2021 Microsoft Corporation. Licensed under the MIT license. 
from .sg_defaults import _C as sg_cfg